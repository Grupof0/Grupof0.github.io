<!DOCTYPE html>
<html>
  <head>
    <title>Grupo f/0. Haciendo de un momento una eternidad</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap2.css" rel="stylesheet">
	<link href="assets/css/estilo.css" rel="stylesheet">
    
    
  </head>
  <body>
	<nav class="navbar navbar-inverse navbar-fixed-top clearfix" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#"><img src="assets/img/logoSm.png"></a>
      </div>
  
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse bajar" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav pull-right letra-grande">
        <li><a href="#info">Info</a></li>
        <li><a href="#libro">Fotografía y Libros</a></li>
        <li><a href="#contacto">Contacto</a></li>
        <li><a href="http://www.blog.grupof0.com" target="_blank">Blog</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </nav>
  <img src="assets/img/_DSC5270-Editar.jpg" class="centrar prime">
  
  <div class="container">
  	<hr class="divisor" id="info">
  	<div class="row">
    	<div class="col-md-4">
        	<h2>¿Qué es Grupo f/0?</h2>
            <p>Es la materialización de ciertos ideales y deseos en la mente de todos los jóvenes venezolanos para dejar registro de lo que está pasando en la fotografía de nuestro país. Es una asociación fotográfica sin fines de lucro que busca producir, promover y difundir el hecho fotográfico, haciendo uso de los fotolibros como nuestra herramienta principal.</p>
        </div>
        <div class="col-md-4">
        	<h2>¿En qué creemos?</h2>
            <p>El Grupo F/0 tienen como misión principal hacerle una batalla al tiempo, hacer de un segundo una eternidad. Trabajamos de manera abierta, convocando e invitando a fotógrafos y otros artistas a participar. Sólo pedimos que se unan a nosotros con un máximo de creatividad, calidad y sentido (de ameritarlo). </p>
        </div>
        <div class="col-md-4">
        	<h2>¿Los objetivos?</h2>
            <p>En Grupo f/0 creemos en la importancia de las publicaciones fotográficas. Por eso hemos fijado como norte la producción de la mayor cantidad de libros posible, siempre con una calidad conceptual y estética del más alto nivel. Buscamos promover la fotografía, pero sobre todo registrar este momento de la fotografia venezolana y preservarlo para el futuro.</p>
        </div>
     </div>
     <div class="row">
     	<div class="col-md-4">
        	 
            <img src="assets/img/c1.jpg">
            <p><a class="btn btn-primary market" role="button" href="convocatorias.html">Convocatorias</a></p>     
        </div>
        <div class="col-md-4">
        	 
            <img src="assets/img/l1.jpg">
            <p><a class="btn btn-primary market" role="button" href="convocatorias.html#libros">Libros</a></p>     
        </div>
        
     	<div class="col-md-4">
        	 
            <img src="assets/img/f1.jpg" class="fondo">
            <p><a class="btn btn-primary market" role="button" href="convocatorias.html#fotografia">Fotografía</a></p>    
        </div>
     </div>
     
    <hr class="divisor" id="libro">
      <div class="row">
        <div class="col-md-12">
          <h1 class="centrar"><a href="simbolos.html">Símbolos, Signos y otras Ficciones</a></h1>
        </div>
      </div>
    <div class="row">
    	<div class="col-md-12">
        	
            <iframe class="center-block" src="//player.vimeo.com/video/83853997" width="600" height="337" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe><div class="xs"></div> <div class="text-center"><p><a href="http://vimeo.com/83853997">Símbolos, signos y otras ficciones</a> from <a href="http://vimeo.com/user18824167" target="_blank">Grupof/0</a> on <a href="https://vimeo.com" target="_blank">Vimeo</a>.</p></div>
        </div>
    </div>
    <div class="row">
      <div class="col-md-12">
          <div class="sm"></div>
           <div class="text-center">
            <div class="btn-group btn-group-lg">
              <a href="simbolos.html" role="button" class="btn btn-primary">¿Qué es?</a>
              <a href="simbolos.html#porque" role="button" class="btn btn-primary">¿Por qué?</a>
              <a href="simbolos.html#como" role="button" class="btn btn-primary">¿Cómo se come?</a>
              <a href="simbolos.html#donde" role="button" class="btn btn-primary">¿Dónde?</a>
              <a href="simbolos.html#quienes" role="button" class="btn btn-primary">¿Quiénes participan?</a>
           </div>
          </div>
      </div>
    </div>
   
        
            
            
            

           
    
    <hr class="divisor" id="contacto">
    
    <div class="row">
    	<div class="col-md-4">
        	<h2 class="titulo">Contáctanos</h2>
            <h4>en info@grupof0.com</h4>
            <h4><small>Valencia, Carabobo</small></h4>
            <div class="sm"></div>
            <h4>Tu opinión es importante</h4>
            
            <div class="sm"></div>
            <form class="form" action="index.php" method="post">
		
		<p class="name">
			<input type="text" name="name" id="name" placeholder="Nombre" required/>
			
		</p>
		
		<p class="email">
			<input type="email" name="email" id="email" placeholder="E-mail" required/>
			
		</p>
		
		
	
		<p class="text">
			<textarea name="text" placeholder="Deja tu comentario" ></textarea>
		</p>
        
        <button type="submit" class="btn btn-primary">Enviar</button>
		<span>
		  <?php
if (isset($_REQUEST['email']))
//if "email" is filled out, send email
  {
  //send email
  $name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['text'];
$formcontent=" From: $name \n Message: $message";
$recipient = "info@grupof0.com";
$subject = "info Grupo f/0";
$mailheader = "From: $email \r\n";
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
echo "¡Gracias!";
  }
else
  {
  
  }
?></span>
		
	</form>
            
        </div>
       <div class="text-center">
        <div class="col-md-8">
          
          <div class="filaImg">
            <a href="http://www.twitter.com/grupofotof0" target="_blank" class="hidden-xs elemento"><img src="assets/img/twitter.png"></a>
            <a href="http://www.twitter.com/grupofotof0" target="_blank" class="hidden-md hidden-sm hidden-lg" ><img src="assets/img/twitterSm.png"></a>
           
            <div class="ancho"></div>
           
            <a href="http://www.facebook.com/grupofotograficof0" target="_blank" class="hidden-xs elemento"><img src="assets/img/facebook.png"></a>
            <a href="http://www.facebook.com/grupofotograficof0" target="_blank" class="hidden-sm hidden-md hidden-lg"><img src="assets/img/facebookSm.png"></a>
          </div>
          
          <div class="xs"></div>
            <a href="http://www.instagram.com/grupof0" target="_blank" class="hidden-xs elemento"><img src="assets/img/instagram.png"></a>
            <a href="http://www.instagram.com/grupof0" target="_blank" class="hidden-md hidden-sm hidden-lg"><img src="assets/img/instagramSm.png"></a>
            <a href="http://vimeo.com/user18824167" target="_blank" class="hidden-xs elemento"><img src="assets/img/vimeo.png"></a>
            <a href="http://vimeo.com/user18824167" target="_blank" class="hidden-sm hidden-md hidden-lg"><img src="assets/img/vimeoSm.png"></a>
          
        </div>
       </div>
    	
        
    </div>
    <hr class="divisor">
    
    <div class="row">
      
    	<div class="col-md-12">
        	<img src="assets/img/blogPSD.jpg" class="img-responsive centrar">
        </div>
      
    </div>
    
    <div class="lg"></div>    
    <footer>
      <p class="pull-right">Diseñado por: <a href="http://kkhenriquez.tumblr.com" target="_blank">Kevin Henriquez</a></p>
      <p>&copy; 2014 Grupo f/0 &middot; Todos los derechos reservados &middot; <a href="http://www.twitter.com/grupofotof0" target="_blank">Twitter</a></p>
    </footer>
  </div>
  
  

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap.min.js"></script>
    
  </body>
</html>